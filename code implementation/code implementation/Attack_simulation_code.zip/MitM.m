% Implementa��o completa - SOC + P_ESS


clear all 
close all

load Neural_SOC_dataset6.mat
load Neural_PESS_dataset6.mat 

name2 = 'Testing_dataset6(24_days_subset).mat';
load(name2);

lenTst = size(P_ESS_Request_W_subset,2);
P_ESS_Request_W_subset = P_ESS_Request_W_subset(1:2:lenTst);
SOC_subset = SOC_subset(1:2:lenTst);
P_ESS_W_subset = P_ESS_W_subset(1:2:lenTst);
lenTst = round(lenTst/2);


len = size(SOC_subset,2);
PESS_est = zeros(1,len-1);
PESS_exp = zeros(1,len-1);
PESS = zeros(1,len-1);
SOC_est = ones(1,len-1);
SOC_exp = ones(1,len-1);
SOC = ones(1,len-1);

% Define the attack signal
    delta_P_Req = zeros(1,len-1); % without Attack signal

    % Attack 1 - during the discharge
    %delta_P_Req(6200:6300)=-12000;  % set the interference
    %delta_P_Req(6600:6700)=12000;  % set the interference
    
    % Attack 2 - during the charge
    delta_P_Req(4000:4500)=-10000;  % set the interference
    




for t = 1:len - 1
  
  % Add the attack signal
  P_Req_line(t)=P_ESS_Request_W_subset(t)+delta_P_Req(t);
    
  % Compute M_exp
  [PESS_exp,SOC_exp]=BESS_model(t,net_PESS,net_SOC,P_ESS_Request_W_subset,P_ESS_W_subset,SOC_subset,PESS_exp,SOC_exp);
  M_exp=[PESS_exp;SOC_exp];
  
  % Compute M_est
  [PESS_est,SOC_est]=BESS_model(t,net_PESS,net_SOC,P_Req_line,P_ESS_W_subset,SOC_subset,PESS_est,SOC_est);
  M_est=[PESS_est;SOC_est];
  
  % Compute M
  [PESS,SOC]=BESS_model(t,net_PESS,net_SOC,P_Req_line,P_ESS_W_subset,SOC_subset,PESS,SOC);
  M=[PESS;SOC];
  
  % Compute delta_M
  delta_M = M_est-M_exp;
  
  % Compute M_line
  M_line = M - delta_M;
  
end     

PESS_line=M_line(1,:);
SOC_line=M_line(2,:);

SOC_est = round(SOC_est*100);
SOC_exp = round(SOC_exp*100);
SOC_line = round(SOC_line*100);
SOC = round(SOC*100);



figure(1)
plot(SOC,'r');
hold on
plot(SOC_line,'b');
plot(SOC_subset(2:len),'k');
legend('SOC in the BESS','Fake SOC','SOC without attack');
hold off

figure(2)
plot(PESS,'r');
hold on
plot(PESS_line,'b');
plot(P_ESS_W_subset(2:len),'k');
legend('PESS in the BESS','Fake PESS','PESS without attack');
hold off

figure(3)
plot(delta_P_Req,'b');
legend('\Delta P_{Req}');
hold off